import asyncio
from .db import ensure_schema

async def main():
    await ensure_schema()

if __name__ == "__main__":
    asyncio.run(main())
