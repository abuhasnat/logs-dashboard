import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .db import ensure_schema
from .routers import logs, aggregates

app = FastAPI(title="Logs API", version="0.1.0")

# Implement CORSMiddleware to ensure web browser access api safely
origins = os.getenv("CORS_ORIGINS", "*").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup():
    await ensure_schema()

# order-safe
app.include_router(aggregates.router, prefix="/logs", tags=["aggregates"])
app.include_router(logs.router,       prefix="/logs", tags=["logs"])
