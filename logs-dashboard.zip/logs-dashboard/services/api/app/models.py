from pydantic import BaseModel
from typing import Optional
from datetime import datetime
import uuid

class LogCreate(BaseModel):
    timestamp: datetime
    severity: str
    source: str
    message: str

class LogUpdate(BaseModel):
    timestamp: Optional[datetime] = None
    severity: Optional[str] = None
    source: Optional[str] = None
    message: Optional[str] = None

class LogOut(LogCreate):
    id: uuid.UUID
    created_at: datetime
    updated_at: datetime
