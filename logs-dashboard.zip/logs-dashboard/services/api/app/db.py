import os, asyncpg, asyncio

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:postgres@localhost:5432/logsdb")
_pool = None

async def get_pool():
    global _pool
    if _pool is None:
        for attempt in range(60):
            try:
                _pool = await asyncpg.create_pool(DATABASE_URL, min_size=1, max_size=10)
                break
            except Exception as e:
                wait = min(1 + attempt*0.1, 3)
                print(f"DB not ready, retrying in {wait:.1f}s... ({e})")
                await asyncio.sleep(wait)
        if _pool is None:
            raise RuntimeError("Failed to connect to database after retries")
    return _pool

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS logs (
  id UUID PRIMARY KEY,
  timestamp TIMESTAMPTZ NOT NULL,
  severity TEXT NOT NULL,
  source TEXT NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_logs_timestamp ON logs (timestamp);
CREATE INDEX IF NOT EXISTS idx_logs_severity ON logs (severity);
CREATE INDEX IF NOT EXISTS idx_logs_source ON logs (source);
"""

async def ensure_schema():
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute(SCHEMA_SQL)
