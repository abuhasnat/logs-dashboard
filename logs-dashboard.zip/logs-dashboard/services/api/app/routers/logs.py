from fastapi import APIRouter, HTTPException, Query
from typing import Optional, List, Any, Dict
from datetime import datetime
import uuid
from ..db import get_pool
from ..models import LogCreate, LogUpdate, LogOut

router = APIRouter()

def parse_csv(value: Optional[str]) -> Optional[List[str]]:
    if not value:
        return None
    return [v.strip() for v in value.split(",") if v.strip()]

@router.post("", response_model=LogOut, status_code=201)
async def create_log(payload: LogCreate):
    pool = await get_pool()
    log_id = uuid.uuid4()
    async with pool.acquire() as conn:
        await conn.execute(
            """INSERT INTO logs (id, timestamp, severity, source, message)
                   VALUES ($1, $2, $3, $4, $5)""",
            log_id, payload.timestamp, payload.severity, payload.source, payload.message
        )
        row = await conn.fetchrow("""SELECT id, timestamp, severity, source, message, created_at, updated_at
                                      FROM logs WHERE id=$1""", log_id)
    return LogOut(**dict(row))

@router.get("", response_model=Dict[str, Any])
async def list_logs(
    from_: Optional[datetime] = Query(None, alias="from"),
    to: Optional[datetime] = None,
    severity: Optional[str] = None,
    source: Optional[str] = None,
    search: Optional[str] = None,
    sort: str = "timestamp",
    order: str = "desc",
    page: int = 1,
    page_size: int = 25
):
    pool = await get_pool()
    where = []
    params = []
    i = 1

    if from_:
        where.append(f"timestamp >= ${i}"); params.append(from_); i += 1
    if to:
        where.append(f"timestamp <= ${i}"); params.append(to); i += 1
    if severity:
        sev = parse_csv(severity)
        where.append(f"severity = ANY(${i})"); params.append(sev); i += 1
    if source:
        src = parse_csv(source)
        where.append(f"source = ANY(${i})"); params.append(src); i += 1
    if search:
        where.append(f"message ILIKE ${i}"); params.append(f"%{search}%"); i += 1

    where_sql = ("WHERE " + " AND ".join(where)) if where else ""

    sort_col = sort if sort in {"timestamp","severity","source","created_at","updated_at"} else "timestamp"
    sort_dir = "DESC" if order.lower() == "desc" else "ASC"
    limit = max(1, min(page_size, 200))
    offset = max(0, (page - 1) * limit)

    async with pool.acquire() as conn:
        total = await conn.fetchval(f"SELECT COUNT(*) FROM logs {where_sql}", *params)
        rows = await conn.fetch(
            f"SELECT id, timestamp, severity, source, message, created_at, updated_at FROM logs {where_sql} ORDER BY {sort_col} {sort_dir} LIMIT {limit} OFFSET {offset}",
            *params
        )
    data = [dict(r) for r in rows]
    return {"data": data, "total": total, "page": page, "page_size": limit}

@router.get("/id/{log_id}", response_model=LogOut)
async def get_log(log_id: uuid.UUID):
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT * FROM logs WHERE id=$1", log_id)
        if not row:
            raise HTTPException(status_code=404, detail="Log not found")
    return LogOut(**dict(row))

@router.put("/id/{log_id}", response_model=LogOut)
async def update_log(log_id: uuid.UUID, payload: LogUpdate):
    pool = await get_pool()
    fields = []
    params = []
    i = 1
    for name, value in payload.model_dump(exclude_unset=True).items():
        fields.append(f"{name} = ${i}")
        params.append(value); i += 1
    if not fields:
        raise HTTPException(status_code=400, detail="No fields to update")
    params.append(log_id)
    async with pool.acquire() as conn:
        await conn.execute(f"UPDATE logs SET {', '.join(fields)}, updated_at = now() WHERE id = ${i}", *params)
        row = await conn.fetchrow("SELECT * FROM logs WHERE id=$1", log_id)
        if not row:
            raise HTTPException(status_code=404, detail="Log not found")
    return LogOut(**dict(row))

@router.delete("/id/{log_id}", status_code=204)
async def delete_log(log_id: uuid.UUID):
    pool = await get_pool()
    async with pool.acquire() as conn:
        res = await conn.execute("DELETE FROM logs WHERE id=$1", log_id)
        if res.endswith("0"):
            raise HTTPException(status_code=404, detail="Log not found")
    return

@router.get("/export.csv")
async def export_csv(
    from_: Optional[datetime] = Query(None, alias="from"),
    to: Optional[datetime] = None,
    severity: Optional[str] = None,
    source: Optional[str] = None,
    search: Optional[str] = None,
):
    pool = await get_pool()
    where = []
    params = []
    i = 1
    if from_: where.append(f"timestamp >= ${i}"); params.append(from_); i+=1
    if to: where.append(f"timestamp <= ${i}"); params.append(to); i+=1
    if severity:
        sev = [s.strip() for s in severity.split(",") if s.strip()]
        where.append(f"severity = ANY(${i})"); params.append(sev); i+=1
    if source:
        src = [s.strip() for s in source.split(",") if s.strip()]
        where.append(f"source = ANY(${i})"); params.append(src); i+=1
    if search:
        where.append(f"message ILIKE ${i}"); params.append(f"%{search}%"); i+=1

    where_sql = ("WHERE " + " AND ".join(where)) if where else ""

    async with pool.acquire() as conn:
        rows = await conn.fetch(
            f"SELECT id, timestamp, severity, source, message FROM logs {where_sql} ORDER BY timestamp DESC LIMIT 10000",
            *params
        )
    import csv
    from io import StringIO
    buf = StringIO()
    writer = csv.writer(buf)
    writer.writerow(["id","timestamp","severity","source","message"])
    for r in rows:
        writer.writerow([r["id"], r["timestamp"].isoformat(), r["severity"], r["source"], r["message"]])
    data = buf.getvalue()
    from fastapi import Response
    return Response(content=data, media_type="text/csv", headers={"Content-Disposition":"attachment; filename=logs.csv"})
