from fastapi import APIRouter, Query
from typing import Optional, Dict, Any, List
from datetime import datetime
from ..db import get_pool

router = APIRouter()

@router.get("/aggregates", response_model=List[Dict[str, Any]])
async def aggregates(
    from_: Optional[datetime] = Query(None, alias="from"),
    to: Optional[datetime] = Query(None),
    severity: Optional[str] = None,
    source: Optional[str] = None,
    bucket: str = "day"  # "hour" | "day"
):
    if bucket not in {"hour", "day"}:
        bucket = "day"

    pool = await get_pool()

    where = []
    params = []
    i = 1

    if from_:
        where.append(f"timestamp >= ${i}"); params.append(from_); i += 1
    if to:
        where.append(f"timestamp <= ${i}"); params.append(to); i += 1

    if severity:
        sev = [s.strip() for s in severity.split(",") if s.strip()]
        where.append(f"severity = ANY(${i})"); params.append(sev); i += 1
    if source:
        src = [s.strip() for s in source.split(",") if s.strip()]
        where.append(f"source = ANY(${i})"); params.append(src); i += 1

    where_sql = ("WHERE " + " AND ".join(where)) if where else ""

    async with pool.acquire() as conn:
        rows = await conn.fetch(
            f"""
            SELECT date_trunc('{bucket}', timestamp) AS bucket, COUNT(*) AS count
            FROM logs
            {where_sql}
            GROUP BY bucket
            ORDER BY bucket
            """,
            *params,
        )

    return [{"bucketStart": r["bucket"].isoformat(), "count": r["count"]} for r in rows]
