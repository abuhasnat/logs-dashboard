'use client';
import { useEffect, useState } from 'react';
import Filters, { Filters as F } from '../components/Filters';
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from 'recharts';
const API = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000';
export default function DashboardPage(){
  const [filters,setFilters]=useState<F>({});
  const [data,setData]=useState<any[]>([]);
  const [error,setError]=useState<string|null>(null);
  useEffect(()=>{ (async()=>{
    setError(null);
    const p=new URLSearchParams({bucket:'day'});
    if(filters.severity) p.set('severity',filters.severity);
    if(filters.source) p.set('source',filters.source);
    const res=await fetch(`${API}/logs/aggregates?${p.toString()}`);
    if(!res.ok){ setError(`Fetch failed (${res.status}): ${await res.text()}`); setData([]); return; }
    const arr=await res.json(); setData(Array.isArray(arr)?arr:[]);
  })(); },[filters?.severity,filters?.source]);
  return (<div>
    <h2>Dashboard</h2>
    <Filters onChange={f=>setFilters(prev=>({...prev,...f}))}/>
    <div style={{width:'100%',height:360,marginTop:12,border:'1px dashed #ccc'}}>
      <ResponsiveContainer>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="bucketStart" /><YAxis allowDecimals={false} /><Tooltip />
          <Line type="monotone" dataKey="count" strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    </div>
    {error && <div style={{color:'crimson',marginTop:8}}>{error}</div>}
    {!error && data.length===0 && <div style={{color:'#666',marginTop:8}}>No data.</div>}
  </div>);
}
