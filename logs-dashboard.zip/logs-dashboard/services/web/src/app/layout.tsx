import './globals.css';
import Link from 'next/link';
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en"><body>
      <div className="topnav">
        <Link href="/logs">Logs</Link>
        <Link href="/logs/new">New</Link>
        <Link href="/dashboard">Dashboard</Link>
      </div>
      <div className="container">{children}</div>
    </body></html>
  );
}
