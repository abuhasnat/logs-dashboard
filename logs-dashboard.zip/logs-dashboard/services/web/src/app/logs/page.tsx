'use client';
import { useEffect, useState } from 'react';
import Filters, { Filters as F } from '../components/Filters';
const API = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000';
export default function LogsPage(){
  const [filters,setFilters]=useState<F>({sort:'timestamp',order:'desc'});
  const [rows,setRows]=useState<any[]>([]); const [total,setTotal]=useState(0); const [error,setError]=useState<string|null>(null);
  useEffect(()=>{ (async()=>{
    setError(null);
    const p=new URLSearchParams({page:'1',page_size:'25',sort:filters.sort??'timestamp',order:filters.order??'desc'});
    if(filters.severity) p.set('severity',filters.severity);
    if(filters.source) p.set('source',filters.source);
    if(filters.search) p.set('search',filters.search);
    const res=await fetch(`${API}/logs?${p.toString()}`);
    if(!res.ok){ setError(`HTTP ${res.status}: ${await res.text()}`); setRows([]); setTotal(0); return; }
    const j=await res.json(); setRows(Array.isArray(j?.data)?j.data:[]); setTotal(Number(j?.total??0));
  })(); },[filters]);
  return (<div>
    <h2>Logs</h2>
    <Filters onChange={f=>setFilters(prev=>({...prev,...f}))}/>
    {error && <div style={{color:'crimson',margin:'8px 0'}}>{error}</div>}
    <table><thead><tr><th>Timestamp</th><th>Severity</th><th>Source</th><th>Message</th><th></th></tr></thead>
    <tbody>
      {(rows??[]).length===0 ? <tr><td colSpan={5} style={{color:'#666'}}>No rows.</td></tr> :
        (rows??[]).map((r:any)=>(<tr key={r.id}>
          <td>{new Date(r.timestamp).toLocaleString()}</td><td>{r.severity}</td><td>{r.source}</td><td>{r.message}</td>
          <td><a href={`/logs/${r.id}`}>open</a></td></tr>))}
    </tbody></table>
    <div style={{marginTop:8}}><a href={`${API}/logs/export.csv`} target="_blank">Export CSV</a> · Total: {total}</div>
  </div>);
}
