'use client';
import { useEffect, useState } from 'react';
const API = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000';
export default function LogDetail({ params }: { params: { id: string } }){
  const { id } = params;
  const [data,setData]=useState<any>(null);
  const [edit,setEdit]=useState<any>({});
  const [msg,setMsg]=useState<string|null>(null);

  const load=async()=>{
    setMsg(null);
    const res=await fetch(`${API}/logs/id/${id}`);
    if(!res.ok){ setMsg(`Error ${res.status}: ${await res.text()}`); setData(null); return; }
    setData(await res.json());
  };
  useEffect(()=>{ load(); },[id]);

  const save=async()=>{
    setMsg(null);
    const res=await fetch(`${API}/logs/id/${id}`,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(edit)});
    if(!res.ok){ setMsg(`Error ${res.status}: ${await res.text()}`); return; }
    setEdit({}); await load(); setMsg('Saved.');
  };
  const del=async()=>{
    if(!confirm('Delete?')) return;
    setMsg(null);
    const res=await fetch(`${API}/logs/id/${id}`,{method:'DELETE'});
    if(!res.ok){ setMsg(`Error ${res.status}: ${await res.text()}`); return; }
    location.href='/logs';
  };

  return (<div>
    <h2>Log Detail</h2>
    {msg && <div style={{color: msg==='Saved.'?'#059669':'crimson'}}>{msg}</div>}
    {!data ? <div style={{color:'#666'}}>Not found.</div> : (<div>
      <div><b>ID:</b> {data.id}</div>
      <div><b>Timestamp:</b> {new Date(data.timestamp).toLocaleString()}</div>
      <div><b>Severity:</b> {data.severity}</div>
      <div><b>Source:</b> {data.source}</div>
      <div><b>Message:</b> {data.message}</div>
      <h3>Edit</h3>
      <div style={{display:'grid',gap:8,maxWidth:420}}>
        <input placeholder="timestamp (ISO)" value={edit.timestamp??''} onChange={e=>setEdit({...edit,timestamp:e.target.value})}/>
        <input placeholder="severity" value={edit.severity??''} onChange={e=>setEdit({...edit,severity:e.target.value})}/>
        <input placeholder="source" value={edit.source??''} onChange={e=>setEdit({...edit,source:e.target.value})}/>
        <textarea placeholder="message" value={edit.message??''} onChange={e=>setEdit({...edit,message:e.target.value})}></textarea>
        <div style={{display:'flex',gap:8}}>
          <button onClick={save}>Save</button>
          <button onClick={del}>Delete</button>
        </div>
      </div>
    </div>)}
  </div>);
}
