'use client';
import { useState } from 'react';
const API = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000';
export default function NewLog(){
  const [form,setForm]=useState<any>({timestamp:'',severity:'INFO',source:'api',message:''});
  const [msg,setMsg]=useState<string|null>(null);
  const submit=async()=>{
    setMsg(null);
    const payload={...form,timestamp:new Date(form.timestamp||Date.now()).toISOString()};
    const res=await fetch(`${API}/logs`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    if(!res.ok){ setMsg(`Error ${res.status}: ${await res.text()}`); return; }
    const d=await res.json(); location.href=`/logs/${d.id}`;
  };
  return (<div><h2>New Log</h2>{msg && <div style={{color:'crimson'}}>{msg}</div>}
    <div style={{display:'grid',gap:8,maxWidth:420}}>
      <input placeholder="timestamp (ISO, or blank for now)" value={form.timestamp} onChange={e=>setForm({...form,timestamp:e.target.value})}/>
      <input placeholder="severity" value={form.severity} onChange={e=>setForm({...form,severity:e.target.value})}/>
      <input placeholder="source" value={form.source} onChange={e=>setForm({...form,source:e.target.value})}/>
      <textarea placeholder="message" value={form.message} onChange={e=>setForm({...form,message:e.target.value})}></textarea>
      <button onClick={submit}>Create</button>
    </div></div>);
}
