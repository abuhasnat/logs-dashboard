'use client';
import { useState } from 'react';
export type Filters = { severity?: string; source?: string; search?: string; sort?: string; order?: 'asc'|'desc' };
export default function Filters({ onChange }: { onChange: (f: Filters) => void }) {
  const [f, setF] = useState<Filters>({ sort:'timestamp', order:'desc' });
  const emit = (patch: Partial<Filters>) => { const next = { ...f, ...patch }; setF(next); onChange(next); };
  return (
    <div style={{display:'grid',gap:8,gridTemplateColumns:'repeat(5,minmax(0,1fr))',marginBottom:12}}>
      <input placeholder="severity CSV" onChange={e=>emit({severity:e.target.value||undefined})}/>
      <input placeholder="source CSV"   onChange={e=>emit({source:e.target.value||undefined})}/>
      <input placeholder="search" onKeyDown={e=>{ if(e.key==='Enter') emit({search:(e.target as HTMLInputElement).value||undefined}); }}/>
      <select defaultValue="timestamp" onChange={e=>emit({sort:e.target.value})}>
        <option value="timestamp">sort: timestamp</option>
        <option value="severity">severity</option>
        <option value="source">source</option>
      </select>
      <select defaultValue="desc" onChange={e=>emit({order:e.target.value as 'asc'|'desc'})}>
        <option value="desc">desc</option><option value="asc">asc</option>
      </select>
    </div>
  );
}
