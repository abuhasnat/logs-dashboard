## Quick start (Docker)

```bash
# from the unzipped project root
docker compose build
docker compose up
# Web UI:  http://localhost:3000
# API docs: http://localhost:8000/docs
```
---

## Adding new logs

1. Open **http://localhost:3000/logs/new**  
2. Fill **severity**, **source**, **message**  
   - **timestamp**: leave blank to use “now”
3. Click **Create** → you’ll be redirected to the new log detail page

---

## Viewing logs & filtering

**Open:** http://localhost:3000/logs

**Filters (top bar):**
- **Severity (CSV)** — e.g. `ERROR` or `WARN,ERROR`
- **Source (CSV)** — e.g. `api` or `api,worker`
- **Search** — free-text in **message** (press **Enter** to apply)
- **Sort** — `timestamp` (default) · `severity` · `source`
- **Order** — `desc` (default) or `asc`

**Examples:**
- Only errors from the API → Severity: `ERROR`, Source: `api`
- Warnings or errors from workers → Severity: `WARN,ERROR`, Source: `worker`
- Anything containing “timeout” → Search: `timeout`, Sort: `timestamp`, Order: `desc`

**Export CSV**  
Footer link downloads current filtered set:
- `GET http://localhost:8000/logs/export.csv`
- Uses the same filters you applied.

---

## Dashboard

**Open:** http://localhost:3000/dashboard

- Line chart of counts grouped by **day**.
- **Defaults to all data** (no time window).  
- You can narrow with the same **severity/source** filters in the UI.
- For a time-bounded query, call the API directly with dates:
  ```
  GET /logs/aggregates?bucket=day&from=2025-09-01T00:00:00Z&to=2025-09-30T23:59:59Z
  ```

---
